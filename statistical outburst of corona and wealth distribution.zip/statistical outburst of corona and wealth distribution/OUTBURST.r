library(tidyverse) 
library(lubridate)
library(rworldmap)
library(rworldxtra)
library(rworldmap)
library(rworldxtra)
library(mlr)
library(prophet)
list.files(path = "../input")
options(scipen=999)
covll <- read_csv("C:\\Users\\Prudhvi\\Desktop\\COVID19_line_list_data.csv",col_names = T)
glimpse(covll)
# NAs per variable
apply(covll,2,function(x) sum(is.na(x)))
covll <- select(covll,-c(X4,link,source,X22,X23,X24,X25,X26,X27))
covll$`reporting date` <- mdy(covll$`reporting date`)
covll$country <- as.factor(covll$country)
covll$gender <- as.factor(covll$gender)
covll$symptom_onset <- mdy(covll$symptom_onset)
covll$hosp_visit_date <- mdy(covll$hosp_visit_date)
covll$exposure_start <- mdy(covll$exposure_start)
covll$exposure_end <- mdy(covll$exposure_end)
covll$death <- mdy(covll$death)
# probably the wrong data to recovered dates ment 2019
covll$recovered <- str_replace_all(covll$recovered,pattern = "1899",replacement = "2019")
covll$recovered <- mdy(covll$recovered)
# 1. Add new variables
#create family variable
family_friends <- str_detect(string = covll$summary,pattern = ("husbend | family | daughter | children
                                             |father | wife | son | married | aunt |
                                             mother| sister | cousin | grandmother |
                                             grandfather | relatives | friend | friends | boyfriend | girlfriend | party"))
data1 <- covll %>% 
  mutate(family_friends=as.numeric(family_friends))
#table(data1$family_friends)
# qplot(x = as.factor(family_friends),fill=family_friends,data = data1,
#       xlab = "0 is not from family_friend, 1 is from family_friends ", main = "Incedents came from family or friends")+
#   theme_bw()


# Create Travel variable
travel <- str_detect(data1$summary, ("travel | traveled | cruise | Cruise | trip | journey | Journey | airport | train | plane | airplane |
                                     traveling | flight | Flight | rail | Tour | tour | ship | Ship | arrived | return | returned | business trip"))
data1 <- data1 %>% 
  mutate(travel=as.numeric(travel))
#table(data1$travel)

# Create airplane variable
airplain <- str_detect(data1$summary, (" airport | Airport| plane |Plane| airplane |Airplane| flight | Flight"))
data1 <- data1 %>% 
  mutate(airplain=as.numeric(airplain))
#table(data1$airplain)

# Create train variable
train <- str_detect(data1$summary,"train | Train | rail | Rail |trainstation|Trainstation")
data1 <- data1 %>% 
  mutate(train=as.numeric(airplain))
#table(data1$airplain)

# Create work variable
work <- str_detect(data1$summary, ("employee | Employee | Business | business | coworker | meeting"))
data1 <- data1 %>% 
  mutate(work=as.numeric(work))
#table(data1$work)

# Create byContact variable
byContact <- str_detect(data1$summary, ("contact | store | mall | shop"))
data1 <- data1 %>% 
  mutate(byContact=as.numeric(byContact))
#table(data1$byContact)

glimpse(data1)
## Symptoms -------------------------------------

# cough
pattern <- ("cough")
cough <- ifelse(is.na(data1$symptom)==T,
                str_detect(data1$summary, pattern),
                str_detect(string = str_c(data1$symptom, data1$summary, sep = " "), pattern))

data1 <- mutate(data1,cough=as.numeric(cough))
#table(data1$cough)

# sputum
pattern <- ("sputum")
sputum <- ifelse(is.na(data1$symptom)==T,
                 str_detect(data1$summary, pattern),
                 str_detect(string = str_c(data1$symptom, data1$summary, sep = " "), pattern))

data1 <- mutate(data1,sputum=as.numeric(sputum))
#table(data1$sputum)

# fever
pattern <- ("fever | Fever")
fever <- ifelse(is.na(data1$symptom)==T,
                str_detect(data1$summary, pattern),
                str_detect(string = str_c(data1$symptom, data1$summary, sep = " "), pattern))

data1 <- mutate(data1,fever=as.numeric(fever))
#table(data1$fever)

# pneumonia
pattern = ("pneumonia")
pneumonia <- ifelse(is.na(data1$symptom)==T,
                    str_detect(data1$summary, pattern),
                    str_detect(string = str_c(data1$symptom, data1$summary, sep = " "), pattern))

data1 <- mutate(data1, pneumonia=as.numeric(pneumonia))
#table(data1$pneumonia)
#x <- data1 %>% filter(pneumonia==1) %>% select(summary)
#x$summary

# throat
pattern = ("throat")
throat <- ifelse(is.na(data1$symptom)==T,
                 str_detect(data1$summary, pattern),
                 str_detect(string = str_c(data1$symptom, data1$summary, sep = " "), pattern))

data1 <- mutate(data1,throat=as.numeric(throat))
#table(data1$throat)
#x <- data1 %>% filter(throat==1) %>% select(summary)
#x$summary


# respiratory
pattern = ("shortness | breath | chest | dyspnea | `shortness of breath`| malaise")
respiratory <- ifelse(is.na(data1$symptom)==T,
                      str_detect(data1$summary, pattern),
                      str_detect(string = str_c(data1$symptom, data1$summary, sep = " "), pattern))

data1 <- mutate(data1,respiratory=as.numeric(respiratory))
#table(data1$respiratory)
#x <- data1 %>% filter(respiratory==1) %>% select(summary)
#x$summary

# diarrhea
pattern = ("diarrhea | abdominal")
diarrhea <- ifelse(is.na(data1$symptom)==T,
                   str_detect(data1$summary, pattern),
                   str_detect(string = str_c(data1$symptom, data1$summary, sep = " "), pattern))

data1 <- mutate(data1,diarrhea=as.numeric(diarrhea))
#table(data1$diarrhea)
#x <- data1 %>% filter(diarrhea==1) %>% select(summary)
#x$summary

# vomiting
pattern = ("vomiting")
vomiting <- ifelse(is.na(data1$symptom)==T,
                   str_detect(data1$summary, pattern),
                   str_detect(string = str_c(data1$symptom, data1$summary, sep = " "), pattern))

data1 <- mutate(data1,vomiting=as.numeric(vomiting))
#table(data1$vomiting)
#x <- data1 %>% filter(vomiting==1) %>% select(summary)
#x$summary

# myalgia
pattern = ("myalgia | body | tired | `sore body` | muscle | muscles | joint | cramp | cramps ")
muscles_pain <- ifelse(is.na(data1$symptom)==T,
                       str_detect(data1$summary, pattern),
                       str_detect(string = str_c(data1$symptom, data1$summary, sep = " "), pattern))

data1 <- mutate(data1,muscles_pain=as.numeric(muscles_pain))
#table(data1$muscles_pain)
#x <- data1 %>% filter(muscles_pain==1) %>% select(summary)

# chill
pattern = ("chill | chills | cold ")
chill <- ifelse(is.na(data1$symptom)==T,
                str_detect(data1$summary, pattern),
                str_detect(string = str_c(data1$symptom, data1$summary, sep = " "), pattern))

data1 <- mutate(data1,chill=as.numeric(chill))
#table(data1$chill)
#x <- data1 %>% filter(chill==1) %>% select(summary)

# headache
pattern = ("headache| head ")
headache <- ifelse(is.na(data1$symptom)==T,
                   str_detect(data1$summary, pattern),
                   str_detect(string = str_c(data1$symptom, data1$summary, sep = " "), pattern))

data1 <- mutate(data1,headache=as.numeric(headache))
#table(data1$headache)
#x <- data1 %>% filter(headache==1) %>% select(summary)
# Dates------------------------------------------------------------------
# exposure start - end
data1 <- mutate(data1, daysExpStr_End=as.numeric(data1$exposure_end-data1$exposure_start))
#data1 %>% select(daysExpStr_End)
# exposure start  - symptoms onset
data1 <- mutate(data1, daysExpStr_SmptOnst=as.numeric(data1$symptom_onset-data1$exposure_start))
# exposure start - hospital visit
data1 <- mutate(data1, daysExpStr_HospVisit=as.numeric(data1$hosp_visit_date-data1$exposure_start))
# exposure start - death
data1 <- mutate(data1,daysExpStr_death = as.numeric(data1$death-data1$exposure_start))
#exposure start - recover
data1 <- mutate(data1, daysExpStr_recover = as.numeric(data1$recovered - data1$exposure_start))
#symptom onset - exposure end
data1 <- mutate(data1, daysSmptOnst_ExpEnd=as.numeric(symptom_onset-exposure_end))
#symptom onset - hospital visit
data1 <- mutate(data1, daysSmptOnst_HospVisit=as.numeric(hosp_visit_date-symptom_onset))
#symptom onset - death
data1 <- mutate(data1, daysSmptOnst_death=as.numeric(death-symptom_onset))
#symptom onset - recovered
data1 <- mutate(data1, daysSmptOnst_recovered=as.numeric(recovered-symptom_onset))
# hospitalVisit - death
data1 <- mutate(data1, dayshsplzed_death=as.numeric(death-hosp_visit_date))
# hospitalVisit - recovered
data1 <- mutate(data1, dayshsplzed_recovered=as.numeric(recovered-hosp_visit_date))
#glimpse(data1)
data1 <- mutate(data1,progress=ifelse(is.na(data1$death)==F,yes="death",
                                      no=ifelse(is.na(data1$recovered)==F,
                                                yes = "recovered",no="on_progress")))

data1$progress <- as_factor(data1$progress)
table(data1$progress)
options(repr.plot.width = 15, repr.plot.height = 10)


ggplot(data1, aes(progress,age))+
  geom_count(aes( col=gender))+
  facet_wrap(~gender)+
  labs(title = "Per Age and Gender")+
  theme_bw()+
  theme(axis.text.x = element_text(colour="grey20",size=20,angle=60,hjust=.5,vjust=.5,face="plain"),
        axis.text.y = element_text(colour="grey20",size=15,angle=0,hjust=.5,vjust=1,face="plain"),
        axis.title.x = element_text(colour="grey20",size=22,angle=0,hjust=.5,vjust=1,face="plain"),
        axis.title.y = element_text(colour="grey20",size=22,angle=90,hjust=.5,vjust=.5,face="plain"),
        legend.text=element_text(size = 18),
        legend.key = element_rect(size = 18),
        legend.title = element_text(size = 19),
        strip.text= element_text(size=17),
        plot.title = element_text(size = rel(2)))
options(repr.plot.width = 10, repr.plot.height = 10)
ggplot(data1, aes(gender,fill=progress))+
  geom_bar()+
  #facet_wrap(~country)+
  labs(title = "Per gender")+
  theme_bw()+
  theme(axis.text.x = element_text(colour="grey20",size=20,angle=60,hjust=.5,vjust=.5,face="plain"),
        axis.text.y = element_text(colour="grey20",size=15,angle=0,hjust=.5,vjust=1,face="plain"),
        axis.title.x = element_text(colour="grey20",size=22,angle=0,hjust=.5,vjust=1,face="plain"),
        axis.title.y = element_text(colour="grey20",size=22,angle=90,hjust=.5,vjust=.5,face="plain"),
        legend.text=element_text(size = 18),
        legend.key = element_rect(size = 18),
        legend.title = element_text(size = 19),
        strip.text= element_text(size=17),
        plot.title = element_text(size = rel(2)))
options(repr.plot.width = 20, repr.plot.height = 20)
ggplot(data1, aes(gender,fill=progress))+
  geom_bar()+
  facet_wrap(~country)+
  labs(title = "Per Gender, Age, Country")+
  theme_bw()+
  theme(axis.text.x = element_text(colour="grey20",size=20,angle=60,hjust=.5,vjust=.5,face="plain"),
        axis.text.y = element_text(colour="grey20",size=15,angle=0,hjust=.5,vjust=1,face="plain"),
        axis.title.x = element_text(colour="grey20",size=22,angle=0,hjust=.5,vjust=1,face="plain"),
        axis.title.y = element_text(colour="grey20",size=22,angle=90,hjust=.5,vjust=.5,face="plain"),
        legend.text=element_text(size = 18),
        legend.key = element_rect(size = 18),
        legend.title = element_text(size = 19),
        strip.text= element_text(size=17),
        plot.title = element_text(size = rel(2)))
options(repr.plot.width = 40, repr.plot.height = 40)
ggplot(data1, aes(gender,fill=progress))+
  geom_bar()+
  facet_wrap(~location)+
  labs(title = "Per Gender, Age, Location")+
  theme_bw()+
  theme(axis.text.x = element_text(colour="grey20",size=28,angle=60,hjust=.5,vjust=.5,face="plain"),
        axis.text.y = element_text(colour="grey20",size=20,angle=0,hjust=.5,vjust=1,face="plain"),
        axis.title.x = element_text(colour="grey20",size=28,angle=0,hjust=.5,vjust=1,face="plain"),
        axis.title.y = element_text(colour="grey20",size=28,angle=90,hjust=.5,vjust=.5,face="plain"),
        legend.text=element_text(size = 22),
        legend.key = element_rect(size = 22),
        legend.title = element_text(size = 24),
        strip.text= element_text(size=22),
        plot.title = element_text(size = rel(5)))
options(repr.plot.width = 20, repr.plot.height = 15)
data1 %>% select(location,country,gender,age,`visiting Wuhan`,`from Wuhan`,family_friends,travel,airplain,train,work,byContact,progress) %>% 
  gather(key="variables",value = "value",-c(location,country,gender,age,progress)) %>% 
  filter(value==1) %>% 
  ggplot(aes(variables, fill=gender))+
  geom_bar()+
  coord_flip()+
  theme_bw()+
  theme(axis.text.x = element_text(colour="grey20",size=20,angle=60,hjust=.5,vjust=.5,face="plain"),
        axis.text.y = element_text(colour="grey20",size=15,angle=0,hjust=.5,vjust=1,face="plain"),
        axis.title.x = element_text(colour="grey20",size=22,angle=0,hjust=.5,vjust=1,face="plain"),
        axis.title.y = element_text(colour="grey20",size=22,angle=90,hjust=.5,vjust=.5,face="plain"),
        legend.text=element_text(size = 18),
        legend.key = element_rect(size = 18),
        legend.title = element_text(size = 19),
        strip.text= element_text(size=17),
        plot.title = element_text(size = rel(2)))
options(repr.plot.width = 20, repr.plot.height = 20)
data1 %>% select(location,country,gender,age,`visiting Wuhan`,`from Wuhan`,family_friends,travel,airplain,train,work,byContact,progress) %>% 
  gather(key="variables",value = "value",-c(location,country,gender,age,progress)) %>% 
  filter(value==1) %>% 
  ggplot(aes(variables, fill=gender))+
  geom_bar()+
  facet_wrap(~country)+
  coord_flip()+
  theme_bw()+
  theme(axis.text.x = element_text(colour="grey20",size=20,angle=60,hjust=.5,vjust=.5,face="plain"),
        axis.text.y = element_text(colour="grey20",size=15,angle=0,hjust=.5,vjust=1,face="plain"),
        axis.title.x = element_text(colour="grey20",size=22,angle=0,hjust=.5,vjust=1,face="plain"),
        axis.title.y = element_text(colour="grey20",size=22,angle=90,hjust=.5,vjust=.5,face="plain"),
        legend.text=element_text(size = 18),
        legend.key = element_rect(size = 18),
        legend.title = element_text(size = 19),
        strip.text= element_text(size=17),
        plot.title = element_text(size = rel(2)))
options(repr.plot.width = 40, repr.plot.height = 40)
data1 %>% select(location,country,gender,age,`visiting Wuhan`,`from Wuhan`,family_friends,travel,airplain,train,work,byContact,progress) %>% 
  gather(key="variables",value = "value",-c(location,country,gender,age,progress)) %>% 
  filter(value==1) %>% 
  ggplot(aes(variables, fill=gender))+
  geom_bar()+
  facet_wrap(~location)+
  coord_flip()+
  theme_bw()+
  theme(axis.text.x = element_text(colour="grey20",size=20,angle=60,hjust=.5,vjust=.5,face="plain"),
        axis.text.y = element_text(colour="grey20",size=15,angle=0,hjust=.5,vjust=1,face="plain"),
        axis.title.x = element_text(colour="grey20",size=22,angle=0,hjust=.5,vjust=1,face="plain"),
        axis.title.y = element_text(colour="grey20",size=22,angle=90,hjust=.5,vjust=.5,face="plain"),
        legend.text=element_text(size = 18),
        legend.key = element_rect(size = 18),
        legend.title = element_text(size = 19),
        strip.text= element_text(size=17),
        plot.title = element_text(size = rel(2)))
options(repr.plot.width = 15, repr.plot.height = 15)
data1 %>% select(location,country,gender,age,progress,cough,sputum,fever,pneumonia,throat,respiratory,diarrhea,vomiting,muscles_pain,chill,headache) %>% 
  gather(key="variables",value = "value",-c(location,country,gender,age,progress)) %>% 
  filter(value==1) %>% 
  ggplot(aes(variables, fill=gender))+
  labs(title = "Symptoms per Gender Total")+
  geom_bar()+
  coord_flip()+
  theme_bw()+
  theme(axis.text.x = element_text(colour="grey20",size=20,angle=60,hjust=.5,vjust=.5,face="plain"),
        axis.text.y = element_text(colour="grey20",size=15,angle=0,hjust=.5,vjust=1,face="plain"),
        axis.title.x = element_text(colour="grey20",size=22,angle=0,hjust=.5,vjust=1,face="plain"),
        axis.title.y = element_text(colour="grey20",size=22,angle=90,hjust=.5,vjust=.5,face="plain"),
        legend.text=element_text(size = 18),
        legend.key = element_rect(size = 18),
        legend.title = element_text(size = 19),
        strip.text= element_text(size=17),
        plot.title = element_text(size = rel(2)))
data1 %>% select(location,country,gender,age,progress,cough,sputum,fever,pneumonia,throat,respiratory,diarrhea,vomiting,muscles_pain,chill,headache) %>% 
  gather(key="variables",value = "value",-c(location,country,gender,age,progress)) %>% 
  filter(value==1) %>% 
  ggplot(aes(variables, fill=progress))+
  labs(title="Symptoms and Progress Total")+
  geom_bar()+
  coord_flip()+
  theme_bw()+
  theme(axis.text.x = element_text(colour="grey20",size=20,angle=60,hjust=.5,vjust=.5,face="plain"),
        axis.text.y = element_text(colour="grey20",size=15,angle=0,hjust=.5,vjust=1,face="plain"),
        axis.title.x = element_text(colour="grey20",size=22,angle=0,hjust=.5,vjust=1,face="plain"),
        axis.title.y = element_text(colour="grey20",size=22,angle=90,hjust=.5,vjust=.5,face="plain"),
        legend.text=element_text(size = 18),
        legend.key = element_rect(size = 18),
        legend.title = element_text(size = 19),
        strip.text= element_text(size=17),
        plot.title = element_text(size = rel(2)))
names(data1)
data1[,c(5,6,7,8,47,36:46)] %>% 
  gather(key="dayVar",value="days",-c(location,country,gender,age,progress)) %>% 
  ggplot(aes(days,age, col=progress))+
  geom_point(aes(alpha=0.1,size=0.005,shape=gender))+
  xlim(-5,45)+
  labs(title = "Age to DayVariables Progress and Gender")+
  facet_wrap(~dayVar,scale = "free_y")+
  theme_bw()+
  theme(axis.text.x = element_text(colour="grey20",size=20,angle=60,hjust=.5,vjust=.5,face="plain"),
        axis.text.y = element_text(colour="grey20",size=15,angle=0,hjust=.5,vjust=1,face="plain"),
        axis.title.x = element_text(colour="grey20",size=22,angle=0,hjust=.5,vjust=1,face="plain"),
        axis.title.y = element_text(colour="grey20",size=22,angle=90,hjust=.5,vjust=.5,face="plain"),
        legend.text=element_text(size = 18),
        legend.key = element_rect(size = 18),
        legend.title = element_text(size = 19),
        strip.text= element_text(size=17),
        plot.title = element_text(size = rel(2)))
library(mlr)
#glimpse(data1)

# lets see how many NA are on each Variable
#apply(data1,2,function(x) sum(is.na(x)))
# i will not use the day variables because there are many NAs and the model will be weak if i use them too.
dataTrain <- data1 %>% select(location, country, gender, age, If_onset_approximated, `visiting Wuhan` , `from Wuhan`,
                              family_friends,travel, airplain, train, work, byContact, cough, sputum, fever, pneumonia, throat, respiratory,
                              diarrhea, vomiting, muscles_pain, chill, headache,progress) %>% rename(visiting_Wuhan=`visiting Wuhan`,from_Wuhan=`from Wuhan`)

#apply(dataTrain,2,function(x) sum(is.na(x)))
# impute numeric variables with "regr.Rpart" method
imputeMethod <- imputeLearner("regr.rpart")
dataTrainImpute <- impute(as.data.frame(dataTrain[,-c(1,2,3)]), classes = list(numeric=imputeMethod),target = "progress")
dataTrainImpute1 <- dataTrainImpute$data
train <- cbind(dataTrain[,c(1,2,3)],dataTrainImpute1)
#apply(train,2,function(x) sum(is.na(x)))

# impute gender values
dataTrainImpute2 <- impute(train, cols = list(gender=imputeConstant("male")),target = "progress")
train <- dataTrainImpute2$data
#apply(train,2,function(x) sum(is.na(x)))

train$location <- str_replace_all(train$location,pattern = (" "),replacement = "_")
train$location <- str_replace_all(train$location, "-",replacement = "_")
train$location <- str_replace_all(train$location, ("\\(|\\)|\\,"),replacement = "_" )
train$location <- as_factor(train$location)
train <- normalizeFeatures(train,target = "progress",method = "standardize")
task <- makeClassifTask(data = train, target = "progress")
options(scipen=999)

# choosing best variables with filter method
filterVals <- generateFilterValuesData(task = task,method = "randomForestSRC_importance")      

options(repr.plot.width =25, repr.plot.height = 15)
plotFilterValues(filterVals)+
  theme_bw()+
  labs(title = "Variable Importance")+
  coord_flip()+
  theme(axis.text.x = element_text(colour="grey20",size=20,angle=60,hjust=.5,vjust=.5,face="plain"),
        axis.text.y = element_text(colour="grey20",size=25,angle=0,hjust=.5,vjust=1,face="plain"),
        axis.title.x = element_text(colour="grey20",size=22,angle=0,hjust=.5,vjust=1,face="plain"),
        axis.title.y = element_text(colour="grey20",size=22,angle=90,hjust=.5,vjust=.5,face="plain"),
        legend.text=element_text(size = 18),
        legend.key = element_rect(size = 18),
        legend.title = element_text(size = 19),
        strip.text= element_text(size=17),
        plot.title = element_text(size = rel(4)))