options(warn=-1)
options(scipen=10000)
library(tidyverse)
library(scales)
library(RColorBrewer)
library(ggthemes)
library(gridExtra)
library(ggrepel)
library(lubridate)
library(cowplot)

data <- read.csv("C:\\Users\\Prudhvi\\Desktop\\covid_19.csv")
data <- data[,c(1:2,4,6:8)]
names(data)[1] <- "ID"

#data$isChina <- ifelse(data$Country %in% c("Mainland China", "China"),"China","Rest of World")
data$Date <- as.Date(data$ObservationDate, format = "%m/%d/%y")

data$Group <- 0
data$Group[data$Country=="Austria"]<-"Europe"
data$Group[data$Country=="Albania"]<-"Europe"
data$Group[data$Country=="Armenia"]<-"Europe"
data$Group[data$Country=="Belgium"]<-"Europe"
data$Group[data$Country=="Bulgaria"]<-"Europe"
data$Group[data$Country=="Croatia"]<-"Europe"
data$Group[data$Country=="Czech Republic"]<-"Europe"
data$Group[data$Country=="Denmark"]<-"Europe"
data$Group[data$Country=="Estonia"]<-"Europe"
data$Group[data$Country=="Finland"]<-"Europe"
data$Group[data$Country=="France"]<-"Europe"
data$Group[data$Country=="Germany"]<-"Europe"
data$Group[data$Country=="Greece"]<-"Europe"
data$Group[data$Country=="Hungary"]<-"Europe"
data$Group[data$Country=="Iceland"]<-"Europe"
data$Group[data$Country=="Ireland"]<-"Europe"
data$Group[data$Country=="Italy"]<-"Europe"
data$Group[data$Country=="Lativia"]<-"Europe"
data$Group[data$Country=="Lithuania"]<-"Europe"
data$Group[data$Country=="Netherlands"]<-"Europe"
data$Group[data$Country=="Poland"]<-"Europe"
data$Group[data$Country=="Portugal"]<-"Europe"
data$Group[data$Country=="Romania"]<-"Europe"
data$Group[data$Country=="Slovakia"]<-"Europe"
data$Group[data$Country=="Slovenia"]<-"Europe"
data$Group[data$Country=="Spain"]<-"Europe"
data$Group[data$Country=="Sweden"]<-"Europe"
data$Group[data$Country=="UK"]<-"Europe"
data$Group[data$Country=="Russia"]<-"Europe"
data$Group[data$Country=="Switzerland"]<-"Europe"
data$Group[data$Country=="Ukraine"]<-"Europe"
data$Group[data$Country=="Belarus"]<-"Europe"
data$Group[data$Country=="Norway"]<-"Europe"
data$Group[data$Country=="San Marino"]<-"Europe"
data$Group[data$Country=="Moldova"]<-"Europe"
data$Group[data$Country=="Malta"]<-"Europe"
data$Group[data$Country=="Liechtenstein"]<-"Europe"
data$Group[data$Country=="Luxembourg"]<-"Europe"

data$Group[data$Country=="China"]<-"East Asia"
data$Group[data$Country=="Mainland China"]<-"East Asia"
data$Group[data$Country=="Japan"]<-"East Asia"
data$Group[data$Country=="South Korea"]<-"East Asia"
data$Group[data$Country=="Mongolia"]<-"East Asia"

data$Group[data$Country=="US"]<-"USA"

data$Group[data$Country=="Argentina"] <- "South America"
data$Group[data$Country=="Bolivia"] <- "South America"
data$Group[data$Country=="Brazil"] <- "South America"
data$Group[data$Country=="Chile"] <- "South America"
data$Group[data$Country=="Colombia"] <- "South America"
data$Group[data$Country=="Ecuador"] <- "South America"
data$Group[data$Country=="Paraguay"] <- "South America"
data$Group[data$Country=="Peru"] <- "South America"
data$Group[data$Country=="Uruguay"] <- "South America"
data$Group[data$Country=="Venezuela"] <- "South America"

data <- data[data$Group!=0,]
data <- data[,-2]
data$isWeekend <- ifelse(weekdays(data$Date) %in% c("Saturday", "Sunday"), "Weekend", "Weekday")
data$WeekOfYear <- week(data$Date)
data$Weekday <- weekdays(data$Date)


data2 <- read.csv("C:\\Users\\Prudhvi\\Desktop\\COVID19_line_list_data.csv")
#data2$isChina <- ifelse(data2$country=="China", "China","Rest of World")
data2$age <- as.numeric(data2$age)
data2 <- data2[between(data2$age, 2, 100),]

data2 <- data2[,c(1,2,3,6)]

data2$Group <- 0
data2$Group[data2$country=="Austria"]<-"Europe"
data2$Group[data2$Country=="Albania"]<-"Europe"
data2$Group[data2$Country=="Armenia"]<-"Europe"
data2$Group[data2$country=="Belgium"]<-"Europe"
data2$Group[data2$country=="Bulgaria"]<-"Europe"
data2$Group[data2$country=="Croatia"]<-"Europe"
data2$Group[data2$country=="Czech Republic"]<-"Europe"
data2$Group[data2$country=="Denmark"]<-"Europe"
data2$Group[data2$country=="Estonia"]<-"Europe"
data2$Group[data2$country=="Finland"]<-"Europe"
data2$Group[data2$country=="France"]<-"Europe"
data2$Group[data2$country=="Germany"]<-"Europe"
data2$Group[data2$country=="Greece"]<-"Europe"
data2$Group[data2$country=="Hungary"]<-"Europe"
data2$Group[data2$Country=="Iceland"]<-"Europe"
data2$Group[data2$country=="Ireland"]<-"Europe"
data2$Group[data2$country=="Italy"]<-"Europe"
data2$Group[data2$country=="Lativia"]<-"Europe"
data2$Group[data2$country=="Lithuania"]<-"Europe"
data2$Group[data2$country=="Netherlands"]<-"Europe"
data2$Group[data2$country=="Poland"]<-"Europe"
data2$Group[data2$country=="Portugal"]<-"Europe"
data2$Group[data2$country=="Romania"]<-"Europe"
data2$Group[data2$country=="Slovakia"]<-"Europe"
data2$Group[data2$country=="Slovenia"]<-"Europe"
data2$Group[data2$country=="Spain"]<-"Europe"
data2$Group[data2$country=="Sweden"]<-"Europe"
data2$Group[data2$country=="UK"]<-"Europe"
data2$Group[data2$country=="Russia"]<-"Europe"
data2$Group[data2$country=="Switzerland"]<-"Europe"
data2$Group[data2$country=="Ukraine"]<-"Europe"
data2$Group[data2$country=="Belarus"]<-"Europe"
data2$Group[data2$country=="Norway"]<-"Europe"
data2$Group[data2$Country=="San Marino"]<-"Europe"
data2$Group[data2$Country=="Moldova"]<-"Europe"
data2$Group[data2$Country=="Malta"]<-"Europe"
data2$Group[data2$Country=="Liechtenstein"]<-"Europe"
data2$Group[data2$Country=="Luxembourg"]<-"Europe"

data2$Group[data2$country=="China"]<-"East Asia"
data2$Group[data2$country=="Mainland China"]<-"East Asia"
data2$Group[data2$country=="Japan"]<-"East Asia"
data2$Group[data2$country=="South Korea"]<-"East Asia"
data2$Group[data2$country=="Mongolia"]<-"East Asia"

data2$Group[data2$Country=="US"]<-"USA"

data2$Group[data2$Group=="Argentina"] <- "South America"
data2$Group[data2$Group=="Bolivia"] <- "South America"
data2$Group[data2$Group=="Brazil"] <- "South America"
data2$Group[data2$Group=="Chile"] <- "South America"
data2$Group[data2$Group=="Colombia"] <- "South America"
data2$Group[data2$Group=="Ecuador"] <- "South America"
data2$Group[data2$Group=="Paraguay"] <- "South America"
data2$Group[data2$Group=="Peru"] <- "South America"
data2$Group[data2$Group=="Uruguay"] <- "South America"
data2$Group[data2$Group=="Venezuela"] <- "South America"

data2 <- data2[data2$Group!=0,]

#data2 <- data2[-4]
set.seed(100)

head <- data[sample(1:nrow(data),5), ]
head <- head[order(head$ID),]
head
Conf <- data %>%
  group_by(Group, Date) %>%
  summarise(x = sum(Confirmed), .groups = 'drop')

ggplot(Conf, aes(Date, x, colour = Group))+
  geom_line(size = 1.9, alpha = 0.85)+
  scale_y_continuous(trans="log10", labels = comma)+
  labs(x = "", y = "Number of confirmed cases (logarithmic scale)", title =  "Confirmation of virus infection (active + past)", 
       subtitle = "by East Asia, Europe, USA and Rest of World", caption = "Made by Michau96/Kaggle")+
  geom_vline(xintercept = as.Date("2020-03-11"), linetype = "longdash", size = 0.25, col = "gray30")+
  geom_label_repel(data = Conf[Conf$Date == max(Conf$Date),], aes(label = paste0(round(x/1000000,2), " m"), colour = Group), hjust = -0.1, fontface = "bold", size = 4.9, alpha = 0.85, show.legend = F)+
  annotate("text", x = as.Date("2020-04-25"), y = 110, label = "WHO announces \n pandemic", size = 4.8)+
  annotate(geom = "curve", x = as.Date("2020-04-25"), y = 32, xend = as.Date("2020-03-14"), yend = 30, curvature = -0.3, arrow = arrow(length = unit(5, "mm")))+
  scale_x_date(date_labels = "%b %d", date_breaks = "50 days", limits = c(min(Conf$Date), max(Conf$Date)+0))+
  scale_colour_brewer(palette = "Set1")+
  theme_fivethirtyeight()+
  theme(legend.position="bottom", legend.direction="horizontal", legend.title = element_blank(), axis.text = element_text(size = 14), plot.caption = element_text(color = "gray20", face = "italic"),
        legend.text = element_text(size = 15), axis.title = element_text(size = 15), axis.line = element_line(size = 0.4, colour = "grey10"),
        plot.background = element_rect(fill = "#d3dae6"), legend.background = element_rect(fill = "#d3dae6"), legend.key = element_rect(fill = "#d3dae6"))
Dea <- data %>%
  group_by(Group, Date) %>%
  summarise(x = sum(Deaths), .groups = 'drop')

ggplot(Dea, aes(Date, x, colour = Group))+
  geom_line(size = 1.9, alpha = 0.85)+
  scale_y_continuous(trans="log10", labels = comma)+
  scale_x_date(date_labels = "%b %d", date_breaks = "50 days", limits = c(min(Dea$Date), max(Dea$Date)+0))+
  labs(x = "", y = "Number of deaths (logarithmic scale)", title =  "Virus fatalities", 
       subtitle = "by East Asia, Europe, USA and Rest of World", caption = "Made by Michau96/Kaggle")+
  geom_label_repel(data = Dea[Dea$Date == max(Dea$Date),], aes(label = paste0(round(x/1000,0), " k"), colour = Group), hjust = -0.1, fontface = "bold", size = 4.9, alpha = 0.85, show.legend = F)+
  scale_colour_brewer(palette = "Set1")+
  theme_fivethirtyeight()+
  theme(legend.position="bottom", legend.direction="horizontal", legend.title = element_blank(), axis.text = element_text(size = 14), plot.caption = element_text(color = "gray20", face = "italic"),
        legend.text = element_text(size = 15), axis.title = element_text(size = 15), axis.line = element_line(size = 0.4, colour = "grey10"), 
        plot.background = element_rect(fill = "#d3dae6"), legend.background = element_rect(fill = "#d3dae6"), legend.key = element_rect(fill = "#d3dae6"))
Tog2 <- cbind(Dea, Conf)
Tog2 <- Tog2[,c(1,2,3,6)]
names(Tog2)[3:4] <- c("Deaths", "Total")
Tog2$Dea2All <- Tog2$Deaths/Tog2$Total
Tog2 <- Tog2[Tog2$Date>"2020-03-09", ]
ggplot(Tog2, aes(Date,Dea2All, colour = Group))+
  geom_line(size = 2.2, alpha = 0.85)+
  labs(x = "", y = "Mortality rate", title =  "Virus mortality", subtitle = "by East Asia, Europe, USA and Rest of World (since Mar 10)", 
       colour = "", caption = "Made by Michau96/Kaggle")+
  geom_label_repel(data = Tog2[Tog2$Date == max(Tog2$Date),], aes(label = paste0(round(Dea2All*100,1), " %"), colour = Group), hjust = -0.1, fontface = "bold", size = 4.9, alpha = 0.85, show.legend = F)+
  scale_y_continuous(labels = scales::percent, limits = c(0,0.105))+
  scale_x_date(date_labels = "%b %d", date_breaks = "40 days", limits = c(min(Tog2$Date), max(Tog2$Date)+0))+
  scale_colour_brewer(palette = "Set1")+
  #annotate("text", x = mean(Tog2$Date)-32, y = 0.0185, label = "1st death \n outside of China", size = 4.5)+
  #annotate("segment", x = mean(Tog2$Date)-33, xend = mean(Tog2$Date)-29.5, y = 0.0137, yend = 0.0093, colour = "forestgreen", size=0.7, alpha=0.7, arrow=arrow())+
  #annotate("text", x = mean(Tog2$Date)-22, y = 0.0315, label = "1st death \n in Europe", size = 4.6)+
  #annotate("segment", x = mean(Tog2$Date)-22, xend = mean(Tog2$Date)-17, y = 0.0267, yend = 0.0215, colour = "deepskyblue4", size=0.7, alpha=0.7, arrow=arrow())+
  theme_fivethirtyeight()+
  theme(legend.position="bottom", legend.direction="horizontal", axis.text = element_text(size = 14), axis.title = element_text(size = 15), plot.caption = element_text(color = "gray20", face = "italic"),
        legend.text = element_text(size = 14), axis.line = element_line(size = 0.4, colour = "grey10"), legend.key = element_rect(fill = "#d3dae6"),
        plot.background = element_rect(fill = "#d3dae6"), legend.background = element_rect(fill = "#d3dae6"))
