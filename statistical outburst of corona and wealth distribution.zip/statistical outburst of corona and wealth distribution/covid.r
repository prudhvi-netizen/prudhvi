library(rwhatsapp)
library(ggplot2)
library(tidyr)
library(lubridate)
library(readr)
library(stringr)
library(dplyr)
library(tm)
library(kableExtra)
library(RColorBrewer)
library(knitr)
library(plotly)
library(htmlwidgets)
library(tidyverse)
library(tidytext)
library(wordcloud)
#Load the data
path <- file.path("C:\\Users\\Prudhvi\\Desktop\\chat.txt")
chat<- read.csv(path,stringsAsFactors = FALSE,header=FALSE)
view(chat)
dmy(chat$V1)
remove<- which(is.na(chat))
chat[-remove,]
chat <- rwa_read("C:\\Users\\Prudhvi\\Desktop\\chat.txt")
# Check a  Preview of the Table Data Format
chat %>% 
  head(10) %>%
  kable() %>% 
  kable_styling(font_size = 10)
glimpse(chat)
chat %>%
  mutate(day = date(time)) %>%
  count(day) %>%
  ggplot(aes(x = day, y = n)) +
  geom_bar(stat = "identity", fill = "#52854C") +
  ylab("") + xlab("") +
  ggtitle("Messages per day")
chat %>%
  unnest_tokens(input = text, output = word) %>%
  
  count(word) %>% 
  # PLOT OF THE TOP 20 MOST USED WORDS IN CONVERSATION
  top_n(30,n) %>% 
  arrange(desc(n)) %>% 
  ggplot(aes(x=reorder(word,n), y=n, fill=n, color=n)) +
  geom_col(show.legend = FALSE, width = .1) +
  geom_point(show.legend = FALSE, size = 3) +
  scale_fill_gradient(low="#2b83ba",high="#d7191c") +
  scale_color_gradient(low="#2b83ba",high="#d7191c") +
  ggtitle("Words most used in conversation in general") +
  xlab("Words") +
  ylab("Number of times the word was used") +
  coord_flip() +
  theme_minimal()
bing <- chat_clean %>%
  inner_join(get_sentiments("bing")) %>%
  count(author, sentiment) %>%
  spread(sentiment, n, fill = 0) %>%
  mutate(sentiment = positive - negative)
bing
bing_word_counts <- chat_clean %>%
  inner_join(get_sentiments("bing")) %>%
  count(word, sentiment, sort = TRUE) %>%
  ungroup()

bing_word_counts %>%
  group_by(sentiment) %>%
  top_n(10) %>%
  ungroup() %>%
  mutate(word = reorder(word, n)) %>%
  ggplot(aes(word, n, fill = sentiment)) +
  geom_col(show.legend = FALSE) +
  facet_wrap(~sentiment, scales = "free_y") +
  labs(y = "Contribution to sentiment",
       x = NULL) +
  coord_flip()
chat_clean %>%
  mutate(day = date(time)) %>%
  count(author) %>%
  ggplot(aes(x = reorder(author, n), y = n)) +
  geom_bar(stat = "identity") +
  ylab("") + xlab("") +
  coord_flip() +
  ggtitle("Number of messages")
chat_clean <- chat %>%
  unnest_tokens(word, text) %>%
  anti_join(stop_words)


chat_clean <- chat_clean %>%
  na.omit(chat_clean)

chat_clean <- chat_clean %>%
  filter(!word %in% to_remove)

chat_clean%>%
  count(word) %>%
  with(wordcloud(word, n,colors = c("#D55E00", "#009E73"), max.words = 100))

chat_clean <- chat %>%
  unnest_tokens(word, text) %>%
  anti_join(stop_words)


chat_clean <- chat_clean %>%
  na.omit(chat_clean)

chat_clean <- chat_clean %>%
  filter(!word %in% to_remove)

library(reshape2)

chat_clean %>%
  inner_join(get_sentiments("bing")) %>%
  count(word, sentiment, sort = TRUE) %>%
  acast(word ~ sentiment, value.var = "n", fill = 0) %>%
  comparison.cloud(colors = c("#D55E00", "#009E73"),max.words = 100)
chat %>%
  unnest_tokens(input = text,
                output = word) %>%
  filter(!word %in% to_remove) %>%
  group_by(author) %>%
  summarise(lex_diversity = n_distinct(word)) %>%
  arrange(desc(lex_diversity)) %>%
  ggplot(aes(x = reorder(author, lex_diversity),
             y = lex_diversity,
             fill = author)) +
  geom_col(show.legend = FALSE) +
  scale_y_continuous(expand = (mult = c(0, 0, 0, 500))) +
  geom_text(aes(label = scales::comma(lex_diversity)), hjust = -0.1) +
  ylab("unique words") +
  xlab("") +
  ggtitle("Lexical Diversity") +
  coord_flip()

o_words <- chat %>%
  unnest_tokens(input = text,
                output = word) %>%
  filter(author != "Karthik") %>% 
  count(word, sort = TRUE) 

chat %>%
  unnest_tokens(input = text,
                output = word) %>%
  filter(author == "Karthik") %>% 
  count(word, sort = TRUE) %>% 
  filter(!word %in% o_words$word) %>% # only select words nobody else uses
  top_n(n = 6, n) %>%
  ggplot(aes(x = reorder(word, n), y = n)) +
  geom_col(show.legend = FALSE) +
  ylab("") + xlab("") +
  coord_flip() +
  ggtitle("Unique words of Karthik")

o_words <- chat %>%
  unnest_tokens(input = text,
                output = word) %>%
  filter(author != "Pavan Karathik") %>% 
  count(word, sort = TRUE) 

chat %>%
  unnest_tokens(input = text,
                output = word) %>%
  filter(author == "Pavan Karathik") %>% 
  count(word, sort = TRUE) %>% 
  filter(!word %in% o_words$word) %>% # only select words nobody else uses
  top_n(n = 6, n) %>%
  ggplot(aes(x = reorder(word, n), y = n)) +
  geom_col(show.legend = FALSE) +
  ylab("") + xlab("") +
  coord_flip() +
  ggtitle("Unique words of  Pavan Karathik")


library("tidyr")
chat %>%
  unnest(emoji) %>%
  count(author, emoji, sort = TRUE) %>%
  group_by(author) %>%
  top_n(n = 6, n) %>%
  ggplot(aes(x = reorder(emoji, n), y = n, fill = author)) +
  geom_col(show.legend = FALSE) +
  ylab("") +
  xlab("") +
  coord_flip() +
  facet_wrap(~author, ncol = 2, scales = "free_y")  +
  ggtitle("Most often used emojis")

chat %>%
  unnest_tokens(input = text,
                output = word) %>%
  count(author, word, sort = TRUE) %>%
  group_by(author) %>%
  top_n(n = 6, n) %>%
  ggplot(aes(x = reorder_within(word, n, author), y = n, fill = author)) +
  geom_col(show.legend = FALSE) +
  ylab("") +
  xlab("") +
  coord_flip() +
  facet_wrap(~author, ncol = 2, scales = "free_y") +
  scale_x_reordered() +
  ggtitle("Most often used words")
#DAYS OF WEEK MOST ACTIVE
# Mutate to add a column Dow ( Day of week )
wdata <- chat %>% mutate(Dow =  wday(as.Date(chat$time), label=TRUE))

dow <- wdata %>% filter(Dow !='') %>% group_by(Dow) %>% summarise(count = n())
ggplot(dow,aes(x=Dow,y = count, fill = Dow))+
  geom_bar(stat = "identity")+
  xlab("Days of the week")+
  ylab("Messages")+
  coord_flip()+
  geom_text(aes(label = scales::comma(count)), hjust = 3) +
  ggtitle("Days most active")+
  theme_minimal()

#MEMBER TOTAL WORDS USED
wdata = chat %>% mutate(word_count = sapply(strsplit(chat$text, " "), length))

words <- wdata %>% group_by(author)%>% summarise(count= sum(word_count))
ggplot(words,aes(x=author,y = count, fill = author))+
  geom_bar(stat = "identity")+
  xlab("Days of the week")+
  ylab("Messages")+
  geom_text(size = 3,aes(label = paste0(scales::comma(count), " (",round(count/sum(count)*100,0) ,"%)")), vjust = -1) +
  ggtitle("WRITTEN WORDS")+
  theme_minimal()